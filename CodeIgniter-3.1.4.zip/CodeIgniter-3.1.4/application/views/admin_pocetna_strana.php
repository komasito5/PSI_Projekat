<!DOCTYPE html>
<html>
   <head>
      <title>ABA FANTASY</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link rel="stylesheet" href="psi_styles.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
   </head>
   <body>
      <div class="container-fluid">
      <div class="row">
      <div class="col-md-3">  </div>
      <div class="col-md-6">
      <div class="row">
         <div class="col-md-12">
            <img class="img-main" src="photos\logo.jpg" >
         </div>
         <div class="row">
            <div class="col-md-12" >
               <nav role="navigation" class="navbar navbar-default">
                  <div id="navbarCollapse" class="collapse navbar-collapse">
                     <ul class="nav navbar-nav">
                        <li class="active" ><a href="<?php echo base_url()?>NalogController/admin_pocetna">Ubacivanje novih igrača</a></li>
                        <li ><a href="<?php echo base_url()?>NalogController/novaEkipa">Unos nove ekipe</a></li>
                        <li><a href="<?php echo base_url()?>NalogController/pokreni_azuriranje">AzurajIgrace</a></li>
                        <li><a href="admin_promena_prelaznog_roka.html">Promena prelaznog roka</a></li>
                     </ul>
                     <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                           <a data-toggle="dropdown" class="dropdown-toggle" href="#"><?php echo $_SESSION["username"];?><b class="caret"></b></a>
                           <ul role="menu" class="dropdown-menu">
                              <li><a href="<?php echo base_url()?>Welcome/index">Odjavite se</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
               </nav>
            </div>
         </div>
      </div>
      <div class="row">
      <div class="col-sm-6">
         <h1>Ubaci novog igraca:</h1>
         <form name="ubacivanje_igraca" id="register-form" action="<?php echo base_url() ?>NalogController/ubaciIgraca" method="post" role="form">
            <div class="form-group">
               <label for="ime_igraca">Ime igrača:</label>
               <input type="text" class="form-control" name="ime_igraca"><br>
               <label for="prezime_igraca">Prezime igrača:</label>
               <input type="text" class="form-control" name="prezime_igraca">
            </div>
            <div class="form-group">
               <label for="datum_rodjenja">Datum rodjenja: </label>
               <input class="form-control" type="date" value="2011-08-19T13:45:00" name="datum_rodjenja"><br>
               <label for="pozicija_igraca">Pozicija:</label><br>
               <select class="custom-select mb-2 mr-sm-2 mb-sm-0" name="pozicija_igraca">
                  <option selected value="PG">PG</option>
                  <option value="SG">SG</option>
                  <option value="SF">SF</option>
                  <option value="PF">PF</option>
                  <option value="C">C</option>
               </select>
            </div>
            <div class="form-group">
               <label for="nacionalnost">Nacionalnost:</label>
               <input type="text" class="form-control" name="nacionalnost"><br>
               <label for="cena">Cena:</label>
               <input class="form-control" type="number" value="50" name="cena">
            </div>
            <div class="form-group">
               <select class="custom-select mb-2 mr-sm-2 mb-sm-0" name="ekipa_igraca">
               <?php
                  foreach ($stvarne_ekipe as $row) {
                      echo '<option value="'.$row->IdEkipa.'">'.$row->Naziv.'</option>';
                  }
                  
                  ?>
               </select>
            </div>
            <div class="form-group">
               <button type="submit" class="btn btn-default">Ubaciigraca</button>
            </div>
         </form>
         </div>
      </div>
      </div>
   </body>
</html>