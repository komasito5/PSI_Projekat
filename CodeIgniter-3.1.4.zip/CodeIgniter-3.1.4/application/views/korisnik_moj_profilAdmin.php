<!DOCTYPE html>
<html>
    <head>
        <title>Aba Fantasy</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link rel="stylesheet" href="psi_styles.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    </head>
    <body>
        <div class="row">
            <div class="col-md-3">  </div>




            <div class="col-md-6"> 
                <div class="row">
                    <div class="col-md-12">
                        <img class="img-main" src="photos\logo.jpg" >
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-12" >

                        <nav role="navigation" class="navbar navbar-default">


                            <div id="navbarCollapse" class="collapse navbar-collapse">
                                <ul class="nav navbar-nav">
                                    <li ><a href="<?php echo base_url()?>NalogController/admin_pocetna">Početna</a></li>
                                    <li><a href="<?php echo base_url()?>RangListaController/rangLista_admin">Rang lista</a></li>
                                    <li><a href="<?php echo base_url()?>TimController/marketAdmin">Market</a></li>
                                    <li><a href="admin_promena_prelaznog_roka.html">Promena prelaznog roka</a></li>
                                </ul>

                                <ul class="nav navbar-nav navbar-right">
                                    <li class="dropdown">
                                        <a data-toggle="dropdown" class="dropdown-toggle" href="#"><?php echo $_SESSION["username"]; ?> <b class="caret"></b></a>
                                        <ul role="menu" class="dropdown-menu">
                                            

                                            <li><a href="<?php echo base_url(); ?>Welcome/index">Odjavite se</a></li>

                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>

                </div>




                <div class="row">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Ime i Prezime</th>
                                <th>Username</th>
                                <th>Email</th>

                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <th scope="row"><?php echo $ImePrezime; ?></th>
                                <td><?php echo $Username; ?></td>
                                <td><?php echo $Email; ?></td>

                            </tr>

                        </tbody>
                    </table>


                </div>
                <br>
                <br>
                <br>
                <div class="row">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Naziv korisnickog tima</th>
                                <th>Ukupan broj osvojenih poena</th>
                                <th>Pozicija na rang listi</th>

                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td scope="row"><?php echo $NazivTima; ?></td>
                                <td><?php echo $Poeni; ?></td>
                                <td><?php echo $Rang; ?>.</td>

                            </tr>

                        </tbody>
                    </table>


                </div>
                <br>
                <br>
                <br>
                
                
                <div class="row">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Ime i Prezime</th>
                                <th>Klub</th>
                                <th>Pozicija</th>

                            </tr>
                        </thead>

                        <tbody>
                            <?php 
                                if ($Row1 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row1_Ime $Row1_Prezime</td>
                                <td>$Row1_Klub</td>
                                <td>$Row1_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
                            <?php 
                                if ($Row2 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row2_Ime $Row2_Prezime</td>
                                <td>$Row2_Klub</td>
                                <td>$Row2_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
                            <?php 
                                if ($Row3 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row3_Ime $Row3_Prezime</td>
                                <td>$Row3_Klub</td>
                                <td>$Row3_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
                            <?php 
                                if ($Row4 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row4_Ime $Row4_Prezime</td>
                                <td>$Row4_Klub</td>
                                <td>$Row4_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
                            <?php 
                                if ($Row5 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row5_Ime $Row5_Prezime</td>
                                <td>$Row5_Klub</td>
                                <td>$Row5_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
                            <?php 
                                if ($Row6 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row6_Ime $Row6_Prezime</td>
                                <td>$Row6_Klub</td>
                                <td>$Row6_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
                            <?php 
                                if ($Row7 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row7_Ime $Row7_Prezime</td>
                                <td>$Row7_Klub</td>
                                <td>$Row7_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
                            <?php 
                                if ($Row8 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row8_Ime $Row8_Prezime</td>
                                <td>$Row8_Klub</td>
                                <td>$Row8_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
                            <?php 
                                if ($Row9 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row9_Ime $Row9_Prezime</td>
                                <td>$Row9_Klub</td>
                                <td>$Row9_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
                            <?php 
                                if ($Row10 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row10_Ime $Row10_Prezime</td>
                                <td>$Row10_Klub</td>
                                <td>$Row10_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
                            <?php 
                                if ($Row11 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row11_Ime $Row11_Prezime</td>
                                <td>$Row11_Klub</td>
                                <td>$Row11_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
                            <?php 
                                if ($Row12 == 0) {
                                        echo "<tr>
                                <td scope=\"row\" colspan=\"3\" align=\"center\">Nema igraca</td>
                                

                            </tr>";
                                    } else {
                                        echo "<tr>
                                <td scope=\"row\">$Row12_Ime $Row12_Prezime</td>
                                <td>$Row12_Klub</td>
                                <td>$Row12_Pozicija</td>

                            </tr>";
                                    }
                            
                            
                            
                            
                            
                            ?>
 
                            

                        </tbody>
                    </table>


                </div>


                <div class="row">
                    <table class="table">
                        <thead>
                            <tr>

                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th>Broj poena osvojen preoteklim kolima</th>
                                <th></th>

                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>64</td>
                                <td>47</td>
                                <td>45</td>

                            </tr>

                        </tbody>
                    </table>

                    <div>
                        <form action="../RangListaController/obrisiKorisnika" method="post">
                            <button type="submit" class="btn btn-default" style="float:right" name="submit" value="<?php echo $id;?>">Obrisi korisnika</button>
                        </form> 
                    </div>
                </div>

            </div>







    </body>
</html>