<!DOCTYPE html>
<html>
    <head>
        <title>ABA FANTASY</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link rel="stylesheet" href="psi_styles.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <style>
        a {
            color : inherit;
        }
        a:hover {
            color: 	838b83;
            text-decoration: none;
        }
    </style>
    </head>
    <body>

        <div class="row">
            <div class="col-md-3">

            </div>


            <div class="col-md-6"> 
                <div class="row">
                    <div class="col-md-12">
                        <img class="img-main" src="photos\logo.jpg" >
                    </div>
                    <div class="row">

                        <div class="col-md-12" >

                            <nav role="navigation" class="navbar navbar-default">


                                <div id="navbarCollapse" class="collapse navbar-collapse">
                                    <ul class="nav navbar-nav">
                                        <li ><a href="<?php echo base_url()?>Welcome/index">Početna</a></li>
                                        <li class="active"><a href="<?php echo base_url()?>RangListaController/rangLista_gost">Rang lista</a></li>

                                        <li><a href="<?php echo base_url();?>TimController/marketAdmin">Igraci</a></li>

                                    </ul>

                                    <ul class="nav navbar-nav navbar-right">
                                        <li class="dropdown">
                                            <a href="<?php echo base_url()?>NalogController/prikazFormeZaPrijavuRegistraciju">Prijavite se</a>
                                            <ul role="menu" class="dropdown-menu">



                                                <li><a href="psi_index.html">Odjavite se</a></li>

                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </nav>
                        </div>

                    </div>
                    <div class="row">
                        <form role="search" class="navbar-form navbar-left">
                            <div class="form-group">
                                <input type="text" placeholder="Pretraga" class="form-control" id="search">
                            </div>
                        </form>
                    </div>
                </div>
                <div id="result"></div>
                <script type="text/javascript">
                    $.post("http://localhost:7080/CodeIgniter-3.1.4/index.php/RangListaController/pretragaRangListaGost", {search: ""}, function (data) {
                            $("#result").html(data);
                            //$('#result').text(data);
                        })
                        
                    $('#search').on("input", function () {
                            var search = $("#search").val();

                            $.post("http://localhost:7080/CodeIgniter-3.1.4/index.php/RangListaController/pretragaRangListaGost", {search: search}, function (data) {
                                $("#result").html(data);
                               
                                //$('#result').text(data);
                            })

                        });
                </script>
                
    </div>

</div>


</body>
</html>