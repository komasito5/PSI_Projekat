<!DOCTYPE html>
<html>
    <head>
        <title>Aba Fantasy</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link rel="stylesheet" href="psi_styles.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    </head>
    <body>
        <div class="row">
            <div class="col-md-3">  </div>




            <div class="col-md-6"> 
                <div class="row">
                    <div class="col-md-12">
                        <img class="img-main" src="photos\logo.jpg" >
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-12" >

                        <nav role="navigation" class="navbar navbar-default">


                            <div id="navbarCollapse" class="collapse navbar-collapse">
                                <ul class="nav navbar-nav">
                                    <li ><a href="<?php echo base_url(); ?>Welcome/index">Početna</a></li>
                                    <li><a href="<?php echo base_url()?>RangListaController/rangLista_gost">Rang lista</a></li>
                                    <li><a href="igraci_korisnik.html">Igrači</a></li>

                                </ul>

                                <ul class="nav navbar-nav navbar-right">
                                    <li class="dropdown">
                                        <a  href="<?php echo base_url()?>NalogController/prikazFormeZaPrijavuRegistraciju">Prijavite se<b ></b></a>
                                        <ul role="menu" class="dropdown-menu">
                                            <li ><a href="<?php echo base_url(); ?>NalogController/korisnik_mojProfil">Moj profil</a></li>
                                            <li><a href="<?php echo base_url() ?>TimController/mojTim">Tim</a></li>

                                            <li><a href="<?php echo base_url(); ?>Welcome/index">Odjavite se</a></li>

                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>

                </div>




                <div class="row">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Ime i Prezime</th>
                                <th>Username</th>
                                <th>Email</th>

                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <th scope="row"><?php echo $ImePrezime; ?></th>
                                <td><?php echo $Username; ?></td>
                                <td><?php echo $Email; ?></td>

                            </tr>

                        </tbody>
                    </table>


                </div>
                <br>
                <br>
                <br>
                <div class="row">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Naziv korisnickog tima</th>
                                <th>Ukupan broj osvojenih poena</th>
                                <th>Pozicija na rang listi</th>

                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td scope="row"><?php echo $NazivTima; ?></td>
                                <td><?php echo $Poeni; ?></td>
                                <td><?php echo $Rang; ?>.</td>

                            </tr>

                        </tbody>
                    </table>


                </div>
                <br>
                <br>
                <br>
                
                
                <div class="row">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Ime i Prezime</th>
                                <th>Klub</th>
                                <th>Pozicija</th>

                            </tr>
                        </thead>

                        <tbody>
                            <?php 
                                for ($i = 0; $i < $BrojRedova; $i++) {
                                    $index = $i + 1;
                                    $ime = "Row" . "$index" . "_Ime";
                                    $prezime = "Row" . "$index" . "_Prezime";
                                    $pozicija = "Row" . "$index" . "_Pozicija";
                                    $klub = "Row" . "$index" . "_Klub";
                                    
                                    echo "<tr>
                                <td scope=\"row\">" . $$ime . " " . $$prezime . "</td>
                                <td>" . $$klub . "</td>
                                <td>" . $$pozicija . "</td>

                            </tr>";
                                }
                            
                            ?>
                            
                            
 
                            

                        </tbody>
                    </table>


                </div>


                <div class="row">
                    <table class="table">
                        <thead>
                            <tr>

                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th>Broj poena osvojen preoteklim kolima</th>
                                <th></th>

                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>64</td>
                                <td>47</td>
                                <td>45</td>

                            </tr>

                        </tbody>
                    </table>


                </div>

            </div>







    </body>
</html>