<!DOCTYPE html>
<html>
    <head>
        <title>Aba Fantasy</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="psi_styles.css">

    </head>
    <body>
        <div class="row">
            <div class="col-md-3">  </div>




            <div class="col-md-6"> 
                <div class="row">
                    <div class="col-md-12">
                        <img class="img-main" src="photos\logo.jpg" >
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-12">

                        <nav role="navigation" class="navbar navbar-default">


                            <div id="navbarCollapse" class="collapse navbar-collapse">
                                <ul class="nav navbar-nav">
                                    <li class="active"><a href="<?php echo base_url()?>NalogController/ulogovaniKorisnik_pocetna">Pocetna</a></li>
                                    <li><a href="<?php echo base_url()?>RangListaController/rangLista_korisnik">Rang lista</a></li>
                                    <li><a href="igraci_gost.html">Igraci</a></li>

                                </ul>

                                <ul class="nav navbar-nav navbar-right">
                                    <li class="dropdown">
                                        <a data-toggle="dropdown" class="dropdown-toggle" href="#"><?php echo $_SESSION["username"]; ?> <b class="caret"></b></a>
                                        <ul role="menu" class="dropdown-menu">
                                            <li><a href="<?php echo base_url(); ?>NalogController/korisnik_mojProfil">Moj Profil</a></li>
                                            <li><a href="<?php echo base_url() ?>TimController/mojTim">Tim</a></li>
                                            <li><a href="<?php echo base_url(); ?>Welcome/index">Odjavi se</a></li>

                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>

                </div>
                <div class="row">
                    <span class="label label-default"> Preostali tokeni:<?php echo $_SESSION["BrojTokena"]; ?> </span>

                </div>

                <div class="row">
                    <div class="col-md-12">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Ime i Prezime</th>

                                    <th>Pozicija</th>


                                    <th>Cena</th>
                                    <th> </th>

                                </tr>
                            </thead>

                            <tbody>
                                <tr>
                                    <?php
                                    if ($Row1 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"1\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row1_Id . "," . $Row1_Cena;

                                        echo "<th scope=\"row\">$Row1_Ime $Row1_Prezime</th>
                                        <td>$Row1_Pozicija</td>
                                        <td>$Row1_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button></td></form>";
                                    }
                                    ?>
                                </tr>
                                <tr>
                                    <?php
                                    if ($Row2 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"2\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row2_Id . "," . $Row2_Cena;

                                        echo "<th scope=\"row\">$Row2_Ime $Row2_Prezime</th>
                                        <td>$Row2_Pozicija</td>
                                        <td>$Row2_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button></td></form>";
                                    }
                                    ?>
                                </tr>
                                <tr>
                                    <?php
                                    if ($Row3 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"3\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row3_Id . "," . $Row3_Cena;

                                        echo "<th scope=\"row\">$Row3_Ime $Row3_Prezime</th>
                                        <td>$Row3_Pozicija</td>
                                        <td>$Row3_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button></td></form>";
                                    }
                                    ?>
                                </tr>
                                <tr> <!--ovde presek-->
                                    <th scope="row"></th>

                                    <td></td>

                                    <td></td>
                                    <td></td>
                                </tr><!--kraj presek-->
                                <tr>
                                    <?php
                                    if ($Row4 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"4\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row4_Id . "," . $Row4_Cena;

                                        echo "<th scope=\"row\">$Row4_Ime $Row4_Prezime</th>
                                        <td>$Row4_Pozicija</td>
                                        <td>$Row4_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button></td></form>";
                                    }
                                    ?>
                                </tr>
                                <tr>
                                    <?php
                                    if ($Row5 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"5\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row5_Id . "," . $Row5_Cena;

                                        echo "<th scope=\"row\">$Row5_Ime $Row5_Prezime</th>
                                        <td>$Row5_Pozicija</td>
                                        <td>$Row5_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button></td></form>";
                                    }
                                    ?>
                                </tr>
                                <tr>
                                    <?php
                                    if ($Row6 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"6\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row6_Id . "," . $Row6_Cena;

                                        echo "<th scope=\"row\">$Row6_Ime $Row6_Prezime</th>
                                        <td>$Row6_Pozicija</td>
                                        <td>$Row6_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button></td></form>";
                                    }
                                    ?>
                                </tr>
                                <tr>
                                    <?php
                                    if ($Row7 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"7\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row7_Id . "," . $Row7_Cena;

                                        echo "<th scope=\"row\">$Row7_Ime $Row7_Prezime</th>
                                        <td>$Row7_Pozicija</td>
                                        <td>$Row7_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button></td></form>";
                                    }
                                    ?>
                                </tr><tr> <!--ovde presek-->
                                    <th scope="row"></th>

                                    <td></td>

                                    <td></td>
                                    <td></td>
                                </tr><!--kraj presek-->
                                <tr>
                                    <?php
                                    if ($Row8 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"8\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row8_Id . "," . $Row8_Cena;

                                        echo "<th scope=\"row\">$Row8_Ime $Row8_Prezime</th>
                                        <td>$Row8_Pozicija</td>
                                        <td>$Row8_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button></td></form>";
                                    }
                                    ?>
                                <tr>
                                    <?php
                                    if ($Row9 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"9\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row9_Id . "," . $Row9_Cena;

                                        echo "<th scope=\"row\">$Row9_Ime $Row9_Prezime</th>
                                        <td>$Row9_Pozicija</td>
                                        <td>$Row9_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button></td></form>";
                                    }
                                    ?>
                                </tr>
                                <tr>
                                    <?php
                                    if ($Row10 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"10\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row10_Id . "," . $Row10_Cena;

                                        echo "<th scope=\"row\">$Row10_Ime $Row10_Prezime</th>
                                        <td>$Row10_Pozicija</td>
                                        <td>$Row10_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button></td></form>";
                                    }
                                    ?>
                                </tr>
                                <tr> <!--ovde presek-->
                                    <th scope="row"></th>

                                    <td></td>

                                    <td></td>
                                    <td></td>
                                </tr><!--kraj presek-->
                                <tr>
                                    <?php
                                    if ($Row11 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"11\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row11_Id . "," . $Row11_Cena;
                                        $imeDugmeta2 = "" . $Row11_Id;
                                        echo "<th scope=\"row\">$Row11_Ime $Row11_Prezime</th>
                                        <td>$Row11_Pozicija</td>
                                        <td>$Row11_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button><button type=\"button\"   class=\"btn btn-default\" data-toggle = \"modal\" data-target = \"#PSIModal\" onclick=\"proslediRezervu(this)\" value=\"$imeDugmeta2\">Dodaj u tim</button></td></form>";
                                    }
                                    ?>
                                </tr>
                                <tr><tr>
                                    <?php
                                    if ($Row12 == 0) {
                                        echo "<th scope=\"row\">Ime i Prezime</th>
                                        <td>Pozicija</td>
                                        <td>Cena</td>
                                        <form action=\"market\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"12\">Kupi  </button></td></form>";
                                    } else {
                                        $imeDugmeta = "" . $Row12_Id . "," . $Row12_Cena;
                                        $imeDugmeta2 = "" . $Row12_Id;
                                        echo "<th scope=\"row\">$Row12_Ime $Row12_Prezime</th>
                                        <td>$Row12_Pozicija</td>
                                        <td>$Row12_Cena</td>
                                        <form action=\"prodajIgraca\" method=\"post\">
                                        <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value = \"$imeDugmeta\">Prodaj</button><button type=\"button\"   class=\"btn btn-default\" data-toggle = \"modal\" data-target = \"#PSIModal\" onclick=\"proslediRezervu(this)\" value=\"$imeDugmeta2\">Dodaj u tim</button></td></form>";
                                    }
                                    ?>
                                </tr>
                                <tr>
                                <tr>


                            </tbody>
                        </table>
                    </div>
                    <div class="modal fade" id="PSIModal" tabindex="-1" role="dialog" aria-labelledby="PSIModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">

                                </div>
                                <div class="modal-body">
                                    <form name="forma" action="<?php echo base_url() ?>TimController/zamenaIgraca" method="post">  
                                        <input type="hidden" id="idRezerve"   name="idRezerve" ></input>
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Ime i Prezime</th>

                                                    <th>Pozicija</th>



                                                    <th> </th>

                                                </tr>
                                            </thead>

                                            <tbody>
                                                <?php
                                                if ($Row1 != 0) {
                                                    $imeDugmeta = "" . $Row1_Id;
                                                    echo "<tr>
                                                    <th scope=\"row\">$Row1_Ime $Row1_Prezime</th>

                                                    <td>$Row1_Pozicija</td>

                                                    
                                                    <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit2\" value = \"$imeDugmeta\">Zameni</button></td>
                                                </tr>";
                                                }

                                                if ($Row2 != 0) {
                                                    $imeDugmeta = "" . $Row2_Id;
                                                    echo "<tr>
                                                    <th scope=\"row\">$Row2_Ime $Row2_Prezime</th>

                                                    <td>$Row2_Pozicija</td>

                                                    
                                                    <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit2\" value = \"$imeDugmeta\">Zameni</button></td>
                                                </tr>";
                                                }

                                                if ($Row3 != 0) {
                                                    $imeDugmeta = "" . $Row3_Id;
                                                    echo "<tr>
                                                    <th scope=\"row\">$Row3_Ime $Row3_Prezime</th>

                                                    <td>$Row3_Pozicija</td>

                                                    
                                                    <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit2\" value = \"$imeDugmeta\">Zameni</button></td>
                                                </tr>";
                                                }

                                                if ($Row4 != 0) {
                                                    $imeDugmeta = "" . $Row4_Id;
                                                    echo "<tr>
                                                    <th scope=\"row\">$Row4_Ime $Row4_Prezime</th>

                                                    <td>$Row4_Pozicija</td>

                                                    
                                                    <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit2\" value = \"$imeDugmeta\">Zameni</button></td>
                                                </tr>";
                                                }

                                                if ($Row5 != 0) {
                                                    $imeDugmeta = "" . $Row5_Id;
                                                    echo "<tr>
                                                    <th scope=\"row\">$Row5_Ime $Row5_Prezime</th>

                                                    <td>$Row5_Pozicija</td>

                                                    
                                                    <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit2\" value = \"$imeDugmeta\">Zameni</button></td>
                                                </tr>";
                                                }

                                                if ($Row6 != 0) {
                                                    $imeDugmeta = "" . $Row6_Id;
                                                    echo "<tr>
                                                    <th scope=\"row\">$Row6_Ime $Row6_Prezime</th>

                                                    <td>$Row6_Pozicija</td>

                                                    
                                                    <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit2\" value = \"$imeDugmeta\">Zameni</button></td>
                                                </tr>";
                                                }

                                                if ($Row7 != 0) {
                                                    $imeDugmeta = "" . $Row7_Id;
                                                    echo "<tr>
                                                    <th scope=\"row\">$Row7_Ime $Row7_Prezime</th>

                                                    <td>$Row7_Pozicija</td>

                                                    
                                                    <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit2\" value = \"$imeDugmeta\">Zameni</button></td>
                                                </tr>";
                                                }

                                                if ($Row8 != 0) {
                                                    $imeDugmeta = "" . $Row8_Id;
                                                    echo "<tr>
                                                    <th scope=\"row\">$Row8_Ime $Row8_Prezime</th>

                                                    <td>$Row8_Pozicija</td>

                                                    
                                                    <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit2\" value = \"$imeDugmeta\">Zameni</button></td>
                                                </tr>";
                                                }

                                                if ($Row9 != 0) {
                                                    $imeDugmeta = "" . $Row9_Id;
                                                    echo "<tr>
                                                    <th scope=\"row\">$Row9_Ime $Row9_Prezime</th>

                                                    <td>$Row9_Pozicija</td>

                                                    
                                                    <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit2\" value = \"$imeDugmeta\">Zameni</button></td>
                                                </tr>";
                                                }

                                                if ($Row10 != 0) {
                                                    $imeDugmeta = "" . $Row10_Id;
                                                    echo "<tr>
                                                    <th scope=\"row\">$Row10_Ime $Row10_Prezime</th>

                                                    <td>$Row10_Pozicija</td>

                                                    
                                                    <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit2\" value = \"$imeDugmeta\">Zameni</button></td>
                                                </tr>";
                                                }
                                                ?>





                                            </tbody>
                                        </table>


                                    </form>
                                </div>
                                <div class="modal-footer">


                                    <button type="button" class="btn btn-default" data-dismiss="modal">Zatvori</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>         





            </div>



        </div>



        <div class="col-md-3">

        </div>



        <script language="javascript">
            function proslediRezervu(e) {
                document.forma.idRezerve.value = e.value;
            }
        </script>
    </body>
</html>