<!DOCTYPE html>
<html>
   <head>
      <title>ABA FANTASY</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link rel="stylesheet" href="psi_styles.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

      <script type="text/javascript">

      function changeValue(id){
         $.ajax({
            url: "<?=site_url('NalogController/ness/" + id +"')?>",
            type: "post",
            success: function(){
               alert("sad");
            }
         });
      }


      // $(document).ready(function() {
      //    $(".submit").click(function(event) {
      //       event.preventDefault();
      //       var user_name = $("input#name").val();
      //       var password = $("input#pwd").val();
      //       jQuery.ajax({
      //          type: "POST",
      //          url: "<?php echo base_url(); ?>" + "index.php/ajax_post_controller/user_data_submit",
      //          dataType: 'json',
      //          data: {name: user_name, pwd: password},
      //          success: function(res) {
      //             if (res){
      //                   jQuery("div#result").show();
      //                   jQuery("div#value").html(res.username);
      //                   jQuery("div#value_pwd").html(res.pwd);
      //             }
      //          }
      //       });
      //    });
      // });
   </script>

   </head>
   <body>
      <div class="container-fluid">
      <div class="row">
      <div class="col-md-3">  </div>
      <div class="col-md-6">
      <div class="row">
         <div class="col-md-12">
            <img class="img-main" src="photos\logo.jpg" >
         </div>
         <div class="row">
            <div class="col-md-12" >
               <nav role="navigation" class="navbar navbar-default">
                  <div id="navbarCollapse" class="collapse navbar-collapse">
                     <ul class="nav navbar-nav">
                        aj mi
                        <li><a href="<?php echo base_url()?>TimController/marketAdmin">Market</a></li>
                        <li><a href="admin_promena_prelaznog_roka.html">Promena prelaznog roka</a></li>
                     </ul>
                     <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                           <a data-toggle="dropdown" class="dropdown-toggle" href="#"><?php echo $_SESSION["username"];?><b class="caret"></b></a>
                           <ul role="menu" class="dropdown-menu">
                              <li><a href="<?php echo base_url()?>Welcome/index">Odjavite se</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
               </nav>
            </div>
         </div>
      </div>
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
               <div class="col-sm-6">
               
               <?php
                  foreach($igraci_kolo as $row){
                     echo "<div class='form-group'>";
                     echo "<div class='col-sm-12'>";
                     echo "<label>".$row->Ime."&nbsp&nbsp".$row->Prezime."&nbsp&nbsp    ".$row->Pozicija."&nbsp&nbsp     ".$row->NazivEkipe.":</label><br>";
                     echo "<div class='col-sm-6'>";
                     echo "<label for='".$row->IdIgrac."poeni'>Poeni:</label>";
                     echo "</div>";
                     echo "<div class='col-sm-6'>";
                     echo "<input type='number' value='0' class='form-control' onblur='changeValue(".$row->IdIgrac.")' name='".$row->IdIgrac."poeni'>";
                     echo "<input type='button' value='Azuriraj' class='form-control' onclick='changeValue(".$row->IdIgrac.")' name='".$row->IdIgrac."poeni1'><br><br>";
                     echo "</div>";
                     echo "</div>";
                     echo "</div>";
                  }
               ?>
               
               </form>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>