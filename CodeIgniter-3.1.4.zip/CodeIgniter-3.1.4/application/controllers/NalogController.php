<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class NalogController extends CI_Controller {

    public function prikazFormeZaPrijavuRegistraciju() {
        $this->load->view('login_or_register.php');
    }

    public function prijava() {
        $username = $_POST["username"];
        $password = $_POST["password"];

        if ($username == "") {
            echo "Nema unetog username!";
            return;
        }

        if ($password == "") {
            echo "Nema unetog password!";
            return;
        }

        $imaKorisnika = $this->fantasy_model->imaKorisnika($username, $password);

        if ($imaKorisnika == false)
            $this->load->view("login_or_register.php");
        else {
            if ($username != "admin")
                $this->ulogovaniKorisnik_pocetna();
            else{
               
                $this->admin_pocetna();
            }
        }
    }

    public function registracija() {
        $this->load->view("gost_registracija.php");
    }

    public function registrujSe() {
        $username = $_POST["username"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $confirmPassword = $_POST["confirm-password"];

        if ($username == "") {
            echo "Nije unet username!";
            return;
        }

        if ($email == "") {
            echo "Nije unet email!";
            return;
        }

        if ($password == "") {
            echo "Nije unet password!";
            return;
        }

        if ($confirmPassword == "") {
            echo "Nije unet confirmPassword!";
            return;
        }

        if ($password != $confirmPassword) {
            echo "Lozinke nisu iste!";
            return;
        }

        if (strlen($username) > 64) {
            echo "Username je predugacak!";
            return;
        }

        if (strlen($email) > 64) {
            echo "Email je predugacak!";
            return;
        }

        if (strlen($password) > 20) {
            echo "Password je predugacak!";
            return;
        }

        $pattern = "/^[a-z0-9]+@[a-z]+\.com$/";

        if (preg_match($pattern, $email) == false) {
            echo "Email nije u odgovarajucem formatu!";
            return;
        }

        $usernameOk = $this->fantasy_model->proveriUsername($username);
        if ($usernameOk == false) {
            echo "Username vec postoji!";
            $this->load->view("login_or_register.php");
            return;
        }

        $this->fantasy_model->registrujKorisnika($username, $password, $email);
        $this->load->view("login_or_register.php");
    }

    public function admin_pocetna() {
        $data['stvarne_ekipe'] = $this->fantasy_model->getEkipe();
        $this->load->view("admin_pocetna_strana.php", $data);
    }

    public function ulogovaniKorisnik_pocetna() {
        $this->load->view("ulogovani_korisnik_homepage.php");
    }

    public function korisnik_mojProfil() {
        $query = $this->fantasy_model->korisnik_mojProfil();

        $row = $query->row_array();

        $data["Username"] = $_SESSION["username"];
        $data["ImePrezime"] = $row["Ime"] . " " . $row["Prezime"];
        $data["Email"] = $row["Email"];
        $data["NazivTima"] = $row["Naziv"];
        $data["Poeni"] = $row["poeni"];
        $data["Rang"] = $row["Rang"] + 1;

        $this->load->view("korisnik_moj_profil.php", $data);
    }

    public function proveraUsername() {
        $data = $this->fantasy_model->proveriUsername($_POST["username"]);

        $output = "";

        if ($data == false)
            $output .= "Vec postoji!";

        echo $output;
    }

    public function admin_profilKorisnika() {
        $id = $_GET["id"];

        $query = $this->fantasy_model->admin_profilKorisnika($id);

        $row = $query->row_array();

        $data["id"] = $id;
        $data["Username"] = $row["KorisnickoIme"];
        $data["ImePrezime"] = $row["Ime"] . " " . $row["Prezime"];
        $data["Email"] = $row["Email"];
        $data["NazivTima"] = $row["Naziv"];
        $data["Poeni"] = $row["poeni"];
        $data["Rang"] = $row["Rang"] + 1;

        $resultArray = $this->fantasy_model->getIgraciKorisnikaAdmin($id);

        $data["Row1"] = 0;
        $data["Row2"] = 0;
        $data["Row3"] = 0;
        $data["Row4"] = 0;
        $data["Row5"] = 0;
        $data["Row6"] = 0;
        $data["Row7"] = 0;
        $data["Row8"] = 0;
        $data["Row9"] = 0;
        $data["Row10"] = 0;
        $data["Row11"] = 0;
        $data["Row12"] = 0;

        foreach ($resultArray as $row) {
            switch ($row["JeRezerva"]) {
                case 1:
                    $data["Row1"] = 1;
                    $data["Row1_Ime"] = $row["Ime"];
                    $data["Row1_Prezime"] = $row["Prezime"];
                    $data["Row1_Pozicija"] = $row["Pozicija"];
                    $data["Row1_Klub"] = $row["Klub"];
                    break;
                case 2:
                    $data["Row2"] = 1;
                    $data["Row2_Ime"] = $row["Ime"];
                    $data["Row2_Prezime"] = $row["Prezime"];
                    $data["Row2_Pozicija"] = $row["Pozicija"];
                    $data["Row2_Klub"] = $row["Klub"];
                    break;
                case 3:
                    $data["Row3"] = 1;
                    $data["Row3_Id"] = $row["IdIgrac"];
                    $data["Row3_Ime"] = $row["Ime"];
                    $data["Row3_Prezime"] = $row["Prezime"];
                    $data["Row3_Pozicija"] = $row["Pozicija"];
                    $data["Row3_Cena"] = $row["Cena"];
                    break;
                case 4:
                    $data["Row4"] = 1;
                    $data["Row4_Ime"] = $row["Ime"];
                    $data["Row4_Prezime"] = $row["Prezime"];
                    $data["Row4_Pozicija"] = $row["Pozicija"];
                    $data["Row4_Klub"] = $row["Klub"];
                    break;
                case 5:
                    $data["Row5"] = 1;
                    $data["Row5_Ime"] = $row["Ime"];
                    $data["Row5_Prezime"] = $row["Prezime"];
                    $data["Row5_Pozicija"] = $row["Pozicija"];
                    $data["Row5_Klub"] = $row["Klub"];
                    break;
                case 6:
                    $data["Row6"] = 1;
                    $data["Row6_Ime"] = $row["Ime"];
                    $data["Row6_Prezime"] = $row["Prezime"];
                    $data["Row6_Pozicija"] = $row["Pozicija"];
                    $data["Row6_Klub"] = $row["Klub"];
                    break;
                case 7:
                    $data["Row7"] = 1;
                    $data["Row7_Ime"] = $row["Ime"];
                    $data["Row7_Prezime"] = $row["Prezime"];
                    $data["Row7_Pozicija"] = $row["Pozicija"];
                    $data["Row7_Klub"] = $row["Klub"];
                    break;
                case 8:
                    $data["Row8"] = 1;
                    $data["Row8_Ime"] = $row["Ime"];
                    $data["Row8_Prezime"] = $row["Prezime"];
                    $data["Row8_Pozicija"] = $row["Pozicija"];
                    $data["Row8_Klub"] = $row["Klub"];
                    break;
                case 9:
                    $data["Row9"] = 1;
                    $data["Row9_Ime"] = $row["Ime"];
                    $data["Row9_Prezime"] = $row["Prezime"];
                    $data["Row9_Pozicija"] = $row["Pozicija"];
                    $data["Row9_Klub"] = $row["Klub"];
                    break;
                case 10:
                    $data["Row10"] = 1;
                    $data["Row10_Ime"] = $row["Ime"];
                    $data["Row10_Prezime"] = $row["Prezime"];
                    $data["Row10_Pozicija"] = $row["Pozicija"];
                    $data["Row10_Klub"] = $row["Klub"];
                    break;
                case 11:
                    $data["Row11"] = 1;
                    $data["Row11_Ime"] = $row["Ime"];
                    $data["Row11_Prezime"] = $row["Prezime"];
                    $data["Row11_Pozicija"] = $row["Pozicija"];
                    $data["Row11_Klub"] = $row["Klub"];
                    break;
                case 12:
                    $data["Row12"] = 1;
                    $data["Row12_Ime"] = $row["Ime"];
                    $data["Row12_Prezime"] = $row["Prezime"];
                    $data["Row12_Pozicija"] = $row["Pozicija"];
                    $data["Row12_Klub"] = $row["Klub"];
                    break;
            }
        }


        $this->load->view("korisnik_moj_profilAdmin.php", $data);
    }

    public function profilIgraca() {
        $idIgrac = $_GET["id"];

        $query = $this->fantasy_model->detaljiIgrac($idIgrac);

        $row = $query->row_array();

        $data["ImePrezime"] = $row["Ime"] . " " . $row["Prezime"];
        $data["Pozicija"] = $row["Pozicija"];
        $data["Klub"] = $row["Klub"];
        $data["DatumRodjenja"] = $row["DatumRodjenja"];
        $data["Nacionalnost"] = $row["Nacionalnost"];
        $data["Cena"] = $row["Cena"];

        $query = $this->fantasy_model->ucinakIgrac($idIgrac);

        $i = 1;
        $sumaPoeni = 0;
        $sumaAsistencije = 0;
        $sumaSkokovi = 0;
        $sumaFaulovi = 0;
        $sumaIndeks = 0;

        foreach ($query->result_array() as $row) {
            $sumaPoeni += $row["Poeni"];
            $sumaAsistencije += $row["Asistencije"];
            $sumaSkokovi += $row["Skokovi"];
            $sumaFaulovi += $row["Faulovi"];
            $sumaIndeks += $row["Indeks"];

            $data["Row" . "$i" . "Kolo"] = $row["IdKolo"];
            $data["Row" . "$i" . "Poeni"] = $row["Poeni"];
            $data["Row" . "$i" . "Asistencije"] = $row["Asistencije"];
            $data["Row" . "$i" . "Skokovi"] = $row["Skokovi"];
            $data["Row" . "$i" . "Faulovi"] = $row["Faulovi"];
            $data["Row" . "$i" . "Indeks"] = $row["Indeks"];
            $i++;
        }

        $prosekPoeni = 0.00;
        $prosekAsistencije = 0.00;
        $prosekSkokovi = 0.00;
        $prosekFaulovi = 0.00;
        $prosekIndeks = 0.00;

        if ($i > 1) {
            $prosekPoeni = $sumaPoeni * 1.0 / ($i - 1);
            $prosekAsistencije = $sumaAsistencije * 1.0 / ($i - 1);
            $prosekSkokovi = $sumaSkokovi * 1.0 / ($i - 1);
            $prosekFaulovi = $sumaFaulovi * 1.0 / ($i - 1);
            $prosekIndeks = $sumaIndeks * 1.0 / ($i - 1);
        }

        $data["prosekPoeni"] = $prosekPoeni;
        $data["prosekAsistencije"] = $prosekAsistencije;
        $data["prosekSkokovi"] = $prosekSkokovi;
        $data["prosekFaulovi"] = $prosekFaulovi;
        $data["prosekIndeks"] = $prosekIndeks;

        $data["BrojRedova"] = $i - 1;

        $this->load->view("igracProfil.php", $data);
    }

    public function korisnik_profilKorisnika() {
        $id = $_GET["id"];
        
        if ($id == $_SESSION["IdKorisnik"]) {
            $this->korisnik_mojProfil();
            return;
        }
        
        $query = $this->fantasy_model->admin_profilKorisnika($id);

        $row = $query->row_array();

        $data["id"] = $id;
        $data["Username"] = $row["KorisnickoIme"];
        $data["ImePrezime"] = $row["Ime"] . " " . $row["Prezime"];
        $data["Email"] = $row["Email"];
        $data["NazivTima"] = $row["Naziv"];
        $data["Poeni"] = $row["poeni"];
        $data["Rang"] = $row["Rang"] + 1;

        $resultArray = $this->fantasy_model->getIgraciKorisnikaKorisnik($id, 1);

        $i = 1;

        foreach ($resultArray as $row) {
            $data["Row" . "$i"] = 1;
            $data["Row" . "$i" . "_Ime"] = $row["Ime"];
            $data["Row" . "$i" . "_Prezime"] = $row["Prezime"];
            $data["Row" . "$i" . "_Pozicija"] = $row["Pozicija"];
            $data["Row" . "$i" . "_Klub"] = $row["Klub"];
            
            $i++;
        }
        
        $data["BrojRedova"] = $i - 1;
        
        $this->load->view("korisnik_moj_profilDrugiKorisnik.php", $data);
    }
    
    public function gost_profilKorisnika() {
        $id = $_GET["id"];

        $query = $this->fantasy_model->admin_profilKorisnika($id);

        $row = $query->row_array();

        $data["id"] = $id;
        $data["Username"] = $row["KorisnickoIme"];
        $data["ImePrezime"] = $row["Ime"] . " " . $row["Prezime"];
        $data["Email"] = $row["Email"];
        $data["NazivTima"] = $row["Naziv"];
        $data["Poeni"] = $row["poeni"];
        $data["Rang"] = $row["Rang"] + 1;

        $resultArray = $this->fantasy_model->getIgraciKorisnikaKorisnik($id, 1);

        $i = 1;

        foreach ($resultArray as $row) {
            $data["Row" . "$i"] = 1;
            $data["Row" . "$i" . "_Ime"] = $row["Ime"];
            $data["Row" . "$i" . "_Prezime"] = $row["Prezime"];
            $data["Row" . "$i" . "_Pozicija"] = $row["Pozicija"];
            $data["Row" . "$i" . "_Klub"] = $row["Klub"];
            
            $i++;
        }
        
        $data["BrojRedova"] = $i - 1;
        
        $this->load->view("korisnik_moj_profilGost.php", $data);
    }
    
    public function ubaciIgraca(){
        $ime = $_POST["ime_igraca"];
        $prezime = $_POST["prezime_igraca"];
        $DatumRodjenja = $_POST["datum_rodjenja"];
        $pozicija = $_POST["pozicija_igraca"];
        $nacionalnost = $_POST["nacionalnost"];
        $cena = $_POST["cena"];
        $ekipa = $_POST["ekipa_igraca"];
        $this->fantasy_model->ubaciIgraca($ime,$prezime,$DatumRodjenja,$pozicija,$nacionalnost,$cena,$ekipa);
        $data['stvarne_ekipe'] = $this->fantasy_model->getEkipe();
        $this->load->view("admin_pocetna_strana.php", $data);    
    }

    public function ubaciEkipu(){
        $ime = $_POST["NazivTimaEkipe"];
        $this->fantasy_model->ubaciEkipu($ime);
        $this->load->view("admin_unos_ekipe.php"); 
    }

    public function novaEkipa(){
         $this->load->view("admin_unos_ekipe.php");
    }

    public function pokreni_azuriranje(){
        //echo "string";
        $data['igraci_kolo'] = $this->fantasy_model->dohvatiSveIgrace1();
        $data['glupost']=0;
        $this->load->view('admin_zavrsettak_kola.php', $data);
    }


    public function ness($id){
        $data['glupost']=$id;
    }

}
