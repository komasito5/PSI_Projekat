<?php

class AdminController extends CI_Controller{

	public function pokreni_azuriranje(){
		echo "string";
		$data['igraci_kolo'] = $this->fantasy_model->dohvatiSveIgrace();
	//	$this->load->view('admin_zavrsettak_kola.php', $data);
	}
}


?>