<!DOCTYPE html>
<html>
   <head>
      <title>ABA FANTASY</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link rel="stylesheet" href="psi_styles.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
      <script type="text/javascript">

         function zapocni(){
            $.ajax({
               type: "POST",
               url: "http://localhost/index.php/AdminController/dodajNovoKolo/",
               success: function(){
                  document.getElementById("btn_pocetak").style.display="none";
                  document.getElementById("prikaz").style.display="block";
               }
            });
         }

         function changeValue(id){
            var str = id + "_id";
            var ucinak = document.getElementById(id).value;
            var kolo = document.getElementById("pomoc").value;
            $.ajax({
               type: "POST",
               url: "http://localhost/index.php/AdminController/azurirajPromenu/",
               data: {
                  "id_igrac":id,
                  "ucinak_igrac":id,
                  "kolo_igrac":kolo
               },
               success: function(){
                  document.getElementById(str).innerHTML = "<span class='glyphicon glyphicon-ok'></span>";
               }
            });
         }
         
      </script>
   </head>
   <body>
      <div class="container-fluid">
      <div class="row">
      <div class="col-md-3">  </div>
      <div class="col-md-6">
         <div class="row">
            <div class="col-md-12">
               <img class="img-main" src="http://localhost/CodeIgniter-3.1.4/images/logo.jpg" >
            </div>
            <div class="row">
               <div class="col-md-12" >
                  <nav role="navigation" class="navbar navbar-default">
                     <div id="navbarCollapse" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav">
                           <li><a href="<?php echo base_url()?>NalogController/admin_pocetna">Ubacivanje novih igrača</a></li>
                           <li ><a href="<?php echo base_url()?>NalogController/novaEkipa">Unos nove ekpe</a></li>
                           <li class="active"><a href="#">Zavrsi kolo</a></li>
                           <li><a href="<?php echo base_url(); ?>TimController/marketAdmin">Market</a></li>
                           <li><a href="<?php echo base_url()?>AdminController/promeniRok">Promena prelaznog roka</a></li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                           <li class="dropdown">
                              <a data-toggle="dropdown" class="dropdown-toggle" href="#"><?php echo $_SESSION["username"];?><b class="caret"></b></a>
                              <ul role="menu" class="dropdown-menu">
                                 <li><a href="<?php echo base_url()?>Welcome/index">Odjavite se</a></li>
                              </ul>
                           </li>
                        </ul>
                     </div>
                  </nav>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-sm-12">
               <h1>Unos ucinka igrača za <b><?php echo $sledece_kolo;?></b><b>.</b> kolo</h1><br>
               <input type="number" name="pomoc" style="display: none;" id="pomoc" value=<?php echo $sledece_kolo;?>><br><br>
               <input type="button" onclick="zapocni()" style="btn" id="btn_pocetak" value="ZAPOCNI AZURIRANJE" >
               <div id="prikaz" style="display: none">
               <h2>Igrači:</h2><br>
               <?php
                  foreach($igraci_kolo as $row){
                     echo "<div class='form-group'>";
                     echo "<div class='col-sm-12'>";
                     echo "<label>".$row->Ime."&nbsp&nbsp".$row->Prezime."&nbsp&nbsp    ".$row->Pozicija."&nbsp&nbsp     ".$row->NazivEkipe.":</label><br>";
                     echo "<div class='col-sm-3'>";
                     echo "<label for='".$row->IdIgrac."poeni'>Poeni:</label>";
                     echo "</div>";
                     echo "<div class='col-sm-3'>";
                     echo "<input type='number' value='0' class='form-control' onblur='changeValue(".$row->IdIgrac.")' name='".$row->IdIgrac."poeni' id='".$row->IdIgrac."'>";
                     echo "</div>";
                     echo "<div class='col-sm-3'>";
                     echo "<input type='button' value='Azuriraj' class='form-control' onclick='changeValue(".$row->IdIgrac.")' name='".$row->IdIgrac."poeni1'>";
                     echo "</div>";
                     echo "<div class='col-sm-3'>";
                     echo "<div id='".$row->IdIgrac."_id'></div><br><br>";
                     echo "</div>";
                     echo "</div>";
                     echo "</div>";
                  }
                  ?>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>