<!DOCTYPE html>
<html>
    <head>
        <title>ABA FANTASY</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link rel="stylesheet" href="psi_styles.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="row">
            <div class="col-md-3">  </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12">
                        <img class="img-main" src="http://localhost/CodeIgniter-3.1.4/images/logo.jpg" >
                    </div>
                    <div class="row">
                        <div class="col-md-12" >
                            <nav role="navigation" class="navbar navbar-default">
                                <div id="navbarCollapse" class="collapse navbar-collapse">
                                    <ul class="nav navbar-nav">
                                        <li class="active"><a href="<?php echo base_url()?>Welcome/index">Početna</a></li>
                                        <li><a href="<?php echo base_url()?>RangListaController/rangLista_gost">Rang lista</a></li>
                                        <li><a href="<?php echo base_url()?>TimController/igraci">Igrači</a></li>
                                    </ul>
                                    <ul class="nav navbar-nav navbar-right">
                                        <li><a href="<?php echo base_url()?>NalogController/prikazFormeZaPrijavuRegistraciju">Prijavite se</a></li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                    <div class="row">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h1 style="text-align: center">Dobrodosli na sajt ABA FANTASY</h1>
                        <h3>Za ovu igru je potrebno da izaberete 12 (10+2) igrača pred početak ABA lige i pratite njihov učinak tokom takmičenja, kao i njihov doprinos vašem timu.</h3>
                        <h4>U ovom takmičenju tokom trajanja ABA lige menjanje (kupovina / prodaja) igrača će biti dozvoljeno nakon svakog kola, do zaključavanja timova, kada će posle svakog kola biti dozvoljena po dva transfera (kupovine / prodaje), kao i kombinovanje sa izmenama sa klupe.</h4>
                        <h5>Ukoliko do sada niste bili registrovani član "ABA Fantasy" ovo je prava prilika da to postanete. Pridružite nam se i proverite koliko ste dobri u sastavljanju idealnog tima u ABA ligi.</h5>
                        <br><br>
                        <br><br>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div id="myCarousel" class="carousel slide" data-ride="carousel">
                            <!-- Indicators -->
                            <ol class="carousel-indicators">
                                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                <li data-target="#myCarousel" data-slide-to="1"></li>
                                <li data-target="#myCarousel" data-slide-to="2"></li>
                                <li data-target="#myCarousel" data-slide-to="3"></li>
                            </ol>
                            <!-- Wrapper for slides -->
                            <div class="carousel-inner">
                                <div class="item active">
                                    <img src="http://localhost/CodeIgniter-3.1.4/images/kosarka3.jpg" alt="Los Angeles">
                                </div>
                                <div class="item">
                                    <img src="http://localhost/CodeIgniter-3.1.4/images/sampioni.jpg" alt="Chicago">
                                </div>
                                <div class="item">
                                    <img src="http://localhost/CodeIgniter-3.1.4/images/grobari.jpg" alt="New York">
                                </div>
                                <div class="item">
                                    <img src="http://localhost/CodeIgniter-3.1.4/images/prsten.jpg" alt="New York">
                                </div>
                            </div>
                            <!-- grobari.jpg -->
                            <!-- Left and right controls -->
                            <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left"></span>
                            <span class="sr-only">Previous</span>
                            </a>
                            <a class="right carousel-control" href="#myCarousel" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right"></span>
                            <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
                <!--  ovo je kraj sredine-->
            </div>
        </div>
    </body>
</html>