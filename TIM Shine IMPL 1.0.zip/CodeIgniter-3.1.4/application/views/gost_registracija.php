<!DOCTYPE html>
<html>
    <head>
        <title>Aba Fantasy</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link rel="stylesheet" href="psi_styles.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <!--include jQuery -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"
        type="text/javascript"></script>

        <!--include jQuery Validation Plugin-->
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.12.0/jquery.validate.min.js"
        type="text/javascript"></script>
        <script type="text/javascript">
            $(function ()
            {
                $("#register-form").validate(
                        {
                            rules:
                                    {
                                        username:
                                                {
                                                    required: true,
                                                    maxlength: 20
                                                },
                                        email:
                                                {
                                                    required: true,
                                                    email: true,
                                                    minlength: 10,
                                                    maxlength: 50
                                                },
                                        password:
                                                {
                                                    required: true,
                                                    maxlength: 20
                                                },
                                        confirm:
                                                {
                                                    required: true,
                                                    maxlength: 20,
                                                    equalTo: "#password"
                                                }
                                        
                                    },
                            messages:
                                    {
                                        username:
                                                {
                                                    required: "Unesite korisnicko ime.",
                                                    maxlength: "Korisnicko ime ne sme biti duze od 20 karaktera."
                                                },
                                        email:
                                                {
                                                    required: "Unesite email.",
                                                    email: "Email nije u odgovarajucem formatu.",
                                                    minlength: "Email ne sme biti kraci od 10 karaktera.",
                                                    maxlength: "Email ne sme biti duzi od 50 karaktera."
                                                },
                                        password:
                                                {
                                                    required: "Unesite lozinku.",
                                                    maxlength: "Lozinka ne sme biti duze od 20 karaktera."
                                                },
                                        confirm:
                                                {
                                                    required: "Unesite potvrdu lozinke.",
                                                    maxlength: "Potvrda lozinke ne sme biti duze od 20 karaktera.",
                                                    equalTo: "Potvrda lozinke nije identicna lozinci."
                                                }
                                    }
                        });
            });
        </script>
    </head>
    <body>
        <div class="row">
            <div class="col-md-3">  </div>




            <div class="col-md-6"> 
                <div class="row">
                    <div class="col-md-12">
                        <img class="img-main" src="http://localhost/CodeIgniter-3.1.4/images/logo.jpg" >
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-12" >

                        <nav role="navigation" class="navbar navbar-default">


                            <div id="navbarCollapse" class="collapse navbar-collapse">
                                <ul class="nav navbar-nav">
                                    <li class="active"><a href="<?php echo base_url() ?>Welcome/index">Početna</a></li>
                                    <li><a href="<?php echo base_url()?>RangListaController/rangLista_gost">Rang lista</a></li>
                                    <li><a href="<?php echo base_url()?>TimController/igraci">Igrači</a></li>

                                </ul>

                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="<?php echo base_url() ?>NalogController/prikazFormeZaPrijavuRegistraciju">Prijavite se</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>

                </div>







            </div>
            <div class="row">

            </div>

            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="panel panel-login">
                                <div class="panel-heading">
                                    <div class="row">

                                        <div class="col-xs-6 col-md-offset-3">
                                            <a href="#" id="register-form-link">Registrujte se</a>
                                        </div>
                                    </div>
                                    <hr>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">

                                            <form id="register-form" action="<?php echo base_url() ?>NalogController/registrujSe" method="post" role="form"> 
                                                <div class="form-group">
                                                    <input type="text" name="username" id="username" tabindex="1" class="form-control" placeholder="Korisnicko ime" value="">
                                                    <div id="result" style="color:red"></div>
                                                </div>
                                                <div class="form-group">
                                                    <input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="Email" value="">
                                                </div>
                                                <div class="form-group">
                                                    <input type="password" name="password" id="password" tabindex="2" class="form-control" placeholder="Lozinka">
                                                </div>
                                                <div class="form-group">
                                                    <input type="password" name="confirm" id="confirm-password" tabindex="2" class="form-control" placeholder="Potvrdite lozinku">
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-6 col-sm-offset-3">
                                                            <input type="submit" name="register-submit" id="register-submit" tabindex="4" class="form-control btn btn-register" value="Registracija" >
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>   



        </div>
    </div>
</div>



<div class="col-md-3">

</div>
<script type="text/javascript">
    $('#username').on("input", function () {
        var username = $("#username").val();
        if (username.length > 0) {
            $.post("http://localhost:7080/CodeIgniter-3.1.4/index.php/NalogController/proveraUsername", {username: username}, function (data) {
                $("#result").html(data);

                //$('#result').text(data);
            })
        }
    });
</script>



</body>
</html>