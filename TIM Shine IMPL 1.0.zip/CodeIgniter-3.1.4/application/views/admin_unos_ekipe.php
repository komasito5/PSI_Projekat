<!DOCTYPE html>
<html>
   <head>
      <title>ABA FANTASY</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link rel="stylesheet" href="psi_styles.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
   </head>
   <body>
      <div class="container-fluid">
      <div class="row">
      <div class="col-md-3">  </div>
      <div class="col-md-6">
      <div class="row">
         <div class="col-md-12">
            <img class="img-main" src="http://localhost/CodeIgniter-3.1.4/images/logo.jpg" >
         </div>
         <div class="row">
            <div class="col-md-12" >
               <nav role="navigation" class="navbar navbar-default">
                  <div id="navbarCollapse" class="collapse navbar-collapse">
                     <ul class="nav navbar-nav">
                        <li><a href="<?php echo base_url()?>NalogController/admin_pocetna">Ubacivanje novih igrača</a></li>
                        <li class="active"><a href="#">Unos nove ekipe</a></li>
                        <li><a href="<?php echo base_url()?>NalogController/pokreni_azuriranje">Zavrsi kolo</a></li>
                        <li><a href="<?php echo base_url(); ?>TimController/marketAdmin">Market</a></li>
                        <li><a href="<?php echo base_url()?>AdminController/promeniRok">Promena prelaznog roka</a></li>
                     </ul>
                     <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                           <a data-toggle="dropdown" class="dropdown-toggle" href="#"><?php echo $_SESSION["username"];?><b class="caret"></b></a>
                           <ul role="menu" class="dropdown-menu">
                              <li><a href="<?php echo base_url()?>Welcome/index">Odjavite se</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
               </nav>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-sm-6">
            <h1>Ubaci novu ekipu u ABA ligi:</h1>
             <form name="ubacivanje_igraca" id="register-form" action="<?php echo base_url() ?>NalogController/ubaciEkipu" method="post" role="form">
            <label for="NazivTimaEkipe">Naziv:</label>
            <input type="text" class="form-control" name="NazivTimaEkipe"><br>
            <input type="submit" class="btn btn-default" name="submit" value="Ubaci novu ekipu">
            </form>
         </div>
      </div>
      </div>
   </body>
</html>