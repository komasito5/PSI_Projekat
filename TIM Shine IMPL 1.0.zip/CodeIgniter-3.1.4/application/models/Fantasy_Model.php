<?php

class Fantasy_Model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
        session_start();
    }

    public function getBrojTokena($idKorisnik) {
        $query = $this->db->query("SELECT BrojTokena AS broj FROM Korisnik WHERE IdKorisnik = $idKorisnik");
        $row = $query->row_array();
        return $row["broj"];
    }

    public function getIgraci() {
        $IdKorisnik = $_SESSION["IdKorisnik"];
        $query = $this->db->query("SELECT I.IdIgrac AS IdIgrac, I.Ime AS Ime, I.Prezime AS Prezime, I.Pozicija AS Pozicija, I.Cena AS Cena, TI.JeRezerva AS JeRezerva FROM tim_igrac TI, igrac I WHERE TI.IdKorisnik = $IdKorisnik AND TI.IdIgrac = I.IdIgrac ORDER BY TI.JeRezerva ASC");

        return $query->result_array();
    }

    public function getEkipe(){
        $query = $this->db->query("SELECT * FROM Ekipa");
        return $query->result();
    }

    public function brojKola(){
        $query = $this->db->query("SELECT COUNT(*) AS broj FROM kolo");
        return $query->row()->broj + 1;
    }

    public function ubaciIgraca($ime,$prezime,$DatumRodjenja,$pozicija,$nacionalnost,$cena,$ekipa){
         $sql = "INSERT INTO igrac (Ime, Prezime, DatumRodjenja, Pozicija, Nacionalnost, Cena, IdEkipa) VALUES ('$ime', '$prezime', '$DatumRodjenja', '$pozicija', '$nacionalnost', '$cena', '$ekipa')";
        $this->db->query($sql);   
    }

    public function dodajKolo(){
        
    }

    public function dodajUcinak($id, $kolo, $ucinak){
        if(brojKola()===$kolo){
            
        }else{
            $query = $this->db->query("SELECT MAX(IdKolo) AS broj FROM kolo");
            $kolo = $query->row()->broj;
        }

        $sql_insert = "INSERT INTO kolo (IdIgrac, IdKolo, Poeni) VALUES('$id', '$kolo', '$ucinak')";
        $this->db->query($sql_insert);
    }


    

    public function ubaciEkipu($ime){
        $query = $this->db->query("SELECT MAX(IdEkipa) AS broj FROM ekipa");
        $row = $query->row();
        $row = $row->broj + 1;
        $sql = "INSERT INTO Ekipa (IdEkipa, Naziv) VALUES ('$row', '$ime')";
        $this->db->query($sql);   
    }


    public function imaKorisnika($username, $password) {
        $query = $this->db->query("SELECT COUNT(*) AS broj FROM korisnik WHERE KorisnickoIme = '$username' AND Sifra = '$password'");
        $row = $query->row();
        if ($row->broj == 0)
            return false;

        $query = $this->db->query("SELECT IdKorisnik FROM korisnik WHERE KorisnickoIme = '$username' AND Sifra = '$password'");
        $row = $query->row();
        $_SESSION["username"] = $username;
        $_SESSION["IdKorisnik"] = $row->IdKorisnik;

        return true;
    }

    public function proveriUsername($username) {
        $query = $this->db->query("SELECT COUNT(*) AS broj FROM korisnik WHERE KorisnickoIme = '$username'");
        $row = $query->row();
        if ($row->broj == 1)
            return false;

        return true;
    }

    public function registrujKorisnika($username, $password, $email) {
        $sql = "INSERT INTO korisnik (KorisnickoIme, Email, Sifra, Ime, Prezime) VALUES ('$username', '$email', '$password', 'Jovan', 'Komatovic')";
        $this->db->query($sql);
    }

    public function dohvatiSveIgraceZaMarket() {
        $idKorisnik = $_SESSION["IdKorisnik"];

        $query = $this->db->query("SELECT I.IdIgrac AS Id, I.Ime AS Ime, I.Prezime AS Prezime, I.Pozicija AS Pozicija, E.Naziv AS Klub, I.Nacionalnost AS Nacionalnost, I.Cena AS Cena"
                . " FROM igrac AS I, ekipa AS E WHERE I.IdEkipa = E.IdEkipa AND NOT EXISTS"
                . " (SELECT 1 FROM tim_igrac WHERE IdKorisnik = $idKorisnik AND IdIgrac = I.IdIgrac)");

        return $query;
    }

    public function kupiIgraca($IdKorisnik, $IdIgrac, $cena) {
        $rezerva = $_SESSION["mesto"];
        $sql = "INSERT INTO tim_igrac (IdKorisnik, IdIgrac, JeRezerva) VALUES ($IdKorisnik, $IdIgrac, $rezerva)";
        $this->db->query($sql);

        $sql = "UPDATE korisnik SET BrojTokena = BrojTokena - $cena WHERE IdKorisnik = $IdKorisnik";
        $this->db->query($sql);
    }

    public function prodajIgraca($IdKorisnik, $IdIgrac, $cena) {
        $sql = "DELETE FROM tim_igrac WHERE IdKorisnik = $IdKorisnik AND IdIgrac = $IdIgrac";
        $this->db->query($sql);

        $sql = "UPDATE korisnik SET BrojTokena = BrojTokena + $cena WHERE IdKorisnik = $IdKorisnik";
        $this->db->query($sql);
    }

    public function dohvatiSveIgrace() {
        $query = $this->db->query("SELECT I.IdIgrac AS Id, I.Ime AS Ime, I.Prezime AS Prezime, I.Pozicija AS Pozicija, E.Naziv AS Klub, I.Nacionalnost AS Nacionalnost, I.Cena AS Cena"
                . " FROM igrac AS I, ekipa AS E WHERE I.IdEkipa = E.IdEkipa"
                . " ORDER BY Cena DESC");

        return $query;
    }

    public function dohvatiSveIgrace1() {
        $query = $this->db->query("SELECT i.IdIgrac as IdIgrac, i.Ime as Ime, i.Prezime as Prezime, i.Pozicija as Pozicija, e.Naziv as NazivEkipe FROM igrac i, ekipa e WHERE i.IdEkipa=e.IdEkipa ORDER BY e.Naziv ASC");
        return $query->result();
    }

    public function promeniCenu($IdIgrac, $cena) {
        $sql = "UPDATE igrac SET Cena = $cena WHERE IdIgrac = $IdIgrac";
        $this->db->query($sql);
    }

    public function dohvatiSveTimove() {
        $query = $this->db->query("SELECT T.IdKorisnik AS Id, T.Naziv AS Naziv, K.KorisnickoIme AS KorisnickoIme, K.poeni AS Rezultat"
                . " FROM tim AS T, korisnik AS K WHERE T.IdKorisnik = K.IdKorisnik"
                . " ORDER BY Rezultat DESC");

        return $query;
    }

    public function obrisiKorisnika($IdKorisnik) {
        $sql = "DELETE FROM korisnik WHERE IdKorisnik = $IdKorisnik";
        $this->db->query($sql);
    }

    public function pretragaAdmin($deoImena) {
        if ($deoImena != "") {
            $query = $this->db->query("SELECT I.IdIgrac AS Id, I.Ime AS Ime, I.Prezime AS Prezime, I.Pozicija AS Pozicija, E.Naziv AS Klub, I.Nacionalnost AS Nacionalnost, I.Cena AS Cena"
                    . " FROM igrac AS I, ekipa AS E WHERE I.IdEkipa = E.IdEkipa AND I.Prezime LIKE '%$deoImena%'"
                    . " ORDER BY Cena DESC");
        } else {
            $query = $this->db->query("SELECT I.IdIgrac AS Id, I.Ime AS Ime, I.Prezime AS Prezime, I.Pozicija AS Pozicija, E.Naziv AS Klub, I.Nacionalnost AS Nacionalnost, I.Cena AS Cena"
                    . " FROM igrac AS I, ekipa AS E WHERE I.IdEkipa = E.IdEkipa"
                    . " ORDER BY Cena DESC");
        }
        return $query;
    }

    public function pretragaKorisnik($deoImena) {
        $idKorisnik = $_SESSION["IdKorisnik"];
        if ($deoImena == "") {
            $query = $this->db->query("SELECT I.IdIgrac AS Id, I.Ime AS Ime, I.Prezime AS Prezime, I.Pozicija AS Pozicija, E.Naziv AS Klub, I.Nacionalnost AS Nacionalnost, I.Cena AS Cena"
                . " FROM igrac AS I, ekipa AS E, korisnik AS K WHERE I.IdEkipa = E.IdEkipa AND I.Cena <= K.BrojTokena AND K.IdKorisnik = $idKorisnik AND NOT EXISTS"
                . " (SELECT 1 FROM tim_igrac WHERE IdKorisnik = $idKorisnik AND IdIgrac = I.IdIgrac)");
        } else {
            $query = $this->db->query("SELECT I.IdIgrac AS Id, I.Ime AS Ime, I.Prezime AS Prezime, I.Pozicija AS Pozicija, E.Naziv AS Klub, I.Nacionalnost AS Nacionalnost, I.Cena AS Cena"
                . " FROM igrac AS I, ekipa AS E, korisnik AS K WHERE I.IdEkipa = E.IdEkipa AND I.Cena <= K.BrojTokena AND K.IdKorisnik = $idKorisnik AND I.Prezime LIKE '%$deoImena%' AND NOT EXISTS"
                . " (SELECT 1 FROM tim_igrac WHERE IdKorisnik = $idKorisnik AND IdIgrac = I.IdIgrac)");
        }
        return $query;
    }
    
    public function korisnik_mojProfil() {
        $idKorisnik = $_SESSION["IdKorisnik"];
        
        $query = $this->db->query("SELECT K.Ime, K.Prezime, K.Email, T.Naziv, K.poeni, (SELECT COUNT(*) FROM Korisnik WHERE poeni > K.poeni) AS Rang"
                . " FROM korisnik AS K, tim AS T WHERE K.IdKorisnik = T.IdKorisnik AND K.IdKorisnik = $idKorisnik");
        
        return $query;
    }
    
    public function zameni($idRezerva, $idIgrac) {
        $idKorisnik = $_SESSION["IdKorisnik"];
        
        $query = $this->db->query("SELECT JeRezerva AS broj FROM tim_igrac WHERE IdKorisnik = $idKorisnik AND IdIgrac = $idRezerva");
        $row = $query->row_array();
        $jeRezervaRezerva = $row["broj"];
        
        $query = $this->db->query("SELECT JeRezerva AS broj FROM tim_igrac WHERE IdKorisnik = $idKorisnik AND IdIgrac = $idIgrac");
        $row = $query->row_array();
        $jeRezervaIgrac = $row["broj"];
        
        $sql = "UPDATE tim_igrac SET JeRezerva = $jeRezervaIgrac WHERE IdKorisnik = $idKorisnik AND IdIgrac = $idRezerva";
        $this->db->query($sql);
        
        $sql = "UPDATE tim_igrac SET JeRezerva = $jeRezervaRezerva WHERE IdKorisnik = $idKorisnik AND IdIgrac = $idIgrac";
        $this->db->query($sql);
    }
    
    public function admin_profilKorisnika($id) {
        $idKorisnik = $id;
        
        $query = $this->db->query("SELECT K.KorisnickoIme, K.Ime, K.Prezime, K.Email, T.Naziv, K.poeni, (SELECT COUNT(*) FROM Korisnik WHERE poeni > K.poeni) AS Rang"
                . " FROM korisnik AS K, tim AS T WHERE K.IdKorisnik = T.IdKorisnik AND K.IdKorisnik = $idKorisnik");
        
        return $query;
    }
    
    public function detaljiIgrac($idIgrac) {
        $query = $this->db->query("SELECT I.IdIgrac AS Id, I.Ime AS Ime, I.Prezime AS Prezime, I.Pozicija AS Pozicija, E.Naziv AS Klub, I.Nacionalnost AS Nacionalnost, I.Cena AS Cena, DATE_FORMAT(I.DatumRodjenja, \"%d/%m/%Y\") AS DatumRodjenja"
                . " FROM igrac AS I, ekipa AS E WHERE I.IdEkipa = E.IdEkipa AND I.IdIgrac = $idIgrac");
        
        return $query;
    }
    
    public function ucinakIgrac($idIgrac) {
        $query = $this->db->query("SELECT U.IdKolo, U.Poeni, U.Asistencije, U.Skokovi, U.Faulovi, (U.Poeni + U.Asistencije + U.Skokovi - U.Faulovi) AS Indeks"
                . " FROM ucinakigrac AS U WHERE IdIgrac = $idIgrac");
        
        return $query;
    }
    
    public function getIgraciKorisnikaAdmin($id) {
        $query = $this->db->query("SELECT I.Ime AS Ime, I.Prezime AS Prezime, I.Pozicija AS Pozicija, E.Naziv AS Klub, TI.JeRezerva AS JeRezerva FROM tim_igrac TI, igrac I, ekipa E WHERE TI.IdKorisnik = $id AND TI.IdIgrac = I.IdIgrac AND E.IdEkipa = I.IdEkipa ORDER BY TI.JeRezerva ASC");

        return $query->result_array();
    }
    
    public function getIgraciKorisnikaKorisnik($idKorisnik, $idKolo) {
        $query = $this->db->query("SELECT I.Ime, I.Prezime, E.Naziv AS Klub, I.Pozicija, U.Poeni, U.Asistencije, U.Skokovi, U.Faulovi, (U.Poeni + U.Asistencije + U.Skokovi - U.Faulovi) AS Indeks"
                . " FROM igrac I, ekipa E, ucinakigrac U"
                . " WHERE I.IdEkipa = E.IdEkipa AND U.IdIgrac = I.IdIgrac and U.IdKolo = $idKolo"
                . " AND I.IdIgrac IN (SELECT IdIgrac FROM tim_igrac WHERE IdKorisnik = $idKorisnik)"
                . " ORDER BY Indeks DESC"
                . " LIMIT 3");
        
        return $query->result_array();
    }
    
    public function pretragaRangListaAdmin($deoImena) {
        if ($deoImena != "") {
            $query = $this->db->query("SELECT K. IdKorisnik, T.Naziv AS Klub, K.KorisnickoIme, K.Prezime AS Prezime, K.poeni AS Rezultat"
                    . " FROM korisnik AS K, tim AS T WHERE T.IdKorisnik = K.IdKorisnik AND K.KorisnickoIme LIKE '%$deoImena%'"
                    . " ORDER BY K.poeni DESC");
        } else {
            $query = $this->db->query("SELECT K.IdKorisnik, T.Naziv AS Klub, K.KorisnickoIme, K.Prezime AS Prezime, K.poeni AS Rezultat"
                    . " FROM korisnik AS K, tim AS T WHERE T.IdKorisnik = K.IdKorisnik"
                    . " ORDER BY K.poeni DESC");
        }
        return $query;
    }
    

}
