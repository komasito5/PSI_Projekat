<?php

class TimController extends CI_Controller {

    public function mojTim() {
        $_SESSION["BrojTokena"] = $this->fantasy_model->getBrojTokena($_SESSION["IdKorisnik"]);

        $resultArray = $this->fantasy_model->getIgraci();

        $data["Row1"] = 0;
        $data["Row2"] = 0;
        $data["Row3"] = 0;
        $data["Row4"] = 0;
        $data["Row5"] = 0;
        $data["Row6"] = 0;
        $data["Row7"] = 0;
        $data["Row8"] = 0;
        $data["Row9"] = 0;
        $data["Row10"] = 0;
        $data["Row11"] = 0;
        $data["Row12"] = 0;

        foreach ($resultArray as $row) {
            switch ($row["JeRezerva"]) {
                case 1:
                    $data["Row1"] = 1;
                    $data["Row1_Id"] = $row["IdIgrac"];
                    $data["Row1_Ime"] = $row["Ime"];
                    $data["Row1_Prezime"] = $row["Prezime"];
                    $data["Row1_Pozicija"] = $row["Pozicija"];
                    $data["Row1_Cena"] = $row["Cena"];
                    break;
                case 2:
                    $data["Row2"] = 1;
                    $data["Row2_Id"] = $row["IdIgrac"];
                    $data["Row2_Ime"] = $row["Ime"];
                    $data["Row2_Prezime"] = $row["Prezime"];
                    $data["Row2_Pozicija"] = $row["Pozicija"];
                    $data["Row2_Cena"] = $row["Cena"];
                    break;
                case 3:
                    $data["Row3"] = 1;
                    $data["Row3_Id"] = $row["IdIgrac"];
                    $data["Row3_Ime"] = $row["Ime"];
                    $data["Row3_Prezime"] = $row["Prezime"];
                    $data["Row3_Pozicija"] = $row["Pozicija"];
                    $data["Row3_Cena"] = $row["Cena"];
                    break;
                case 4:
                    $data["Row4"] = 1;
                    $data["Row4_Id"] = $row["IdIgrac"];
                    $data["Row4_Ime"] = $row["Ime"];
                    $data["Row4_Prezime"] = $row["Prezime"];
                    $data["Row4_Pozicija"] = $row["Pozicija"];
                    $data["Row4_Cena"] = $row["Cena"];
                    break;
                case 5:
                    $data["Row5"] = 1;
                    $data["Row5_Id"] = $row["IdIgrac"];
                    $data["Row5_Ime"] = $row["Ime"];
                    $data["Row5_Prezime"] = $row["Prezime"];
                    $data["Row5_Pozicija"] = $row["Pozicija"];
                    $data["Row5_Cena"] = $row["Cena"];
                    break;
                case 6:
                    $data["Row6"] = 1;
                    $data["Row6_Id"] = $row["IdIgrac"];
                    $data["Row6_Ime"] = $row["Ime"];
                    $data["Row6_Prezime"] = $row["Prezime"];
                    $data["Row6_Pozicija"] = $row["Pozicija"];
                    $data["Row6_Cena"] = $row["Cena"];
                    break;
                case 7:
                    $data["Row7"] = 1;
                    $data["Row7_Id"] = $row["IdIgrac"];
                    $data["Row7_Ime"] = $row["Ime"];
                    $data["Row7_Prezime"] = $row["Prezime"];
                    $data["Row7_Pozicija"] = $row["Pozicija"];
                    $data["Row7_Cena"] = $row["Cena"];
                    break;
                case 8:
                    $data["Row8"] = 1;
                    $data["Row8_Id"] = $row["IdIgrac"];
                    $data["Row8_Ime"] = $row["Ime"];
                    $data["Row8_Prezime"] = $row["Prezime"];
                    $data["Row8_Pozicija"] = $row["Pozicija"];
                    $data["Row8_Cena"] = $row["Cena"];
                    break;
                case 9:
                    $data["Row9"] = 1;
                    $data["Row9_Id"] = $row["IdIgrac"];
                    $data["Row9_Ime"] = $row["Ime"];
                    $data["Row9_Prezime"] = $row["Prezime"];
                    $data["Row9_Pozicija"] = $row["Pozicija"];
                    $data["Row9_Cena"] = $row["Cena"];
                    break;
                case 10:
                    $data["Row10"] = 1;
                    $data["Row10_Id"] = $row["IdIgrac"];
                    $data["Row10_Ime"] = $row["Ime"];
                    $data["Row10_Prezime"] = $row["Prezime"];
                    $data["Row10_Pozicija"] = $row["Pozicija"];
                    $data["Row10_Cena"] = $row["Cena"];
                    break;
                case 11:
                    $data["Row11"] = 1;
                    $data["Row11_Id"] = $row["IdIgrac"];
                    $data["Row11_Ime"] = $row["Ime"];
                    $data["Row11_Prezime"] = $row["Prezime"];
                    $data["Row11_Pozicija"] = $row["Pozicija"];
                    $data["Row11_Cena"] = $row["Cena"];
                    break;
                case 12:
                    $data["Row12"] = 1;
                    $data["Row12_Id"] = $row["IdIgrac"];
                    $data["Row12_Ime"] = $row["Ime"];
                    $data["Row12_Prezime"] = $row["Prezime"];
                    $data["Row12_Pozicija"] = $row["Pozicija"];
                    $data["Row12_Cena"] = $row["Cena"];
                    break;
            }
        }

        $this->load->view("moj_tim_korisnik.php", $data);
    }

    public function market() {
        $_SESSION["mesto"] = $_POST["submit"];
        $query = $this->fantasy_model->dohvatiSveIgraceZaMarket();

        $i = 1;
        foreach ($query->result_array() as $row) {
            $data["Row" . "$i" . "Id"] = $row["Id"];
            $data["Row" . "$i" . "Ime"] = $row["Ime"];
            $data["Row" . "$i" . "Prezime"] = $row["Prezime"];
            $data["Row" . "$i" . "Pozicija"] = $row["Pozicija"];
            $data["Row" . "$i" . "Klub"] = $row["Klub"];
            $data["Row" . "$i" . "Nacionalnost"] = $row["Nacionalnost"];
            $data["Row" . "$i" . "Cena"] = $row["Cena"];
            $i++;
        }

        $data["BrojRedova"] = $i - 1;

        $this->load->view("market.php", $data);
    }

    public function kupiIgraca() {
        $string = $_POST["btnKupi"];
        $niz = explode(',', $string);
        $idIgrac = $niz[0];
        $cena = $niz[1];

        if ($_SESSION["BrojTokena"] < $cena) {
            echo "Nema dovoljno novca!";
            return;
        }
        $this->fantasy_model->kupiIgraca($_SESSION["IdKorisnik"], $idIgrac, $cena);
        $this->mojTim();
    }
    
    public function kupiIgracaIzProfila() {
        $string = $_POST["submit"];
        $niz = explode(',', $string);
        $idIgrac = $niz[0];
        $cena = $niz[1];

        if ($_SESSION["BrojTokena"] < $cena) {
            echo "Nema dovoljno novca!";
            return;
        }
        $this->fantasy_model->kupiIgraca($_SESSION["IdKorisnik"], $idIgrac, $cena);
        $this->mojTim();
    }

    public function prodajIgraca() {
        $string = $_POST["submit"];
        $niz = explode(',', $string);
        $idIgrac = $niz[0];
        $cena = $niz[1];
        $this->fantasy_model->prodajIgraca($_SESSION["IdKorisnik"], $idIgrac, $cena);

        $this->mojTim();
    }

    public function marketAdmin() {
        $query = $this->fantasy_model->dohvatiSveIgrace();

        $i = 1;
        foreach ($query->result_array() as $row) {
            $data["Row" . "$i" . "Id"] = $row["Id"];
            $data["Row" . "$i" . "Ime"] = $row["Ime"];
            $data["Row" . "$i" . "Prezime"] = $row["Prezime"];
            $data["Row" . "$i" . "Pozicija"] = $row["Pozicija"];
            $data["Row" . "$i" . "Klub"] = $row["Klub"];
            $data["Row" . "$i" . "Nacionalnost"] = $row["Nacionalnost"];
            $data["Row" . "$i" . "Cena"] = $row["Cena"];
            $i++;
        }

        $data["BrojRedova"] = $i - 1;

        $this->load->view("admin_market.php", $data);
    }

    public function promeniCenu() {
        $imeCene = "Cena" . $_POST["submit"];
        $cena = $_POST["cena"];
        $pattern = "/^[1-9](\d)*$/";

        if (preg_match($pattern, $cena) == false) {
            echo "Cena nije u odgovarajucem formatu!";
            return;
        }

        if ($cena > 100) {
            echo "Cena je previsoka!";
            return;
        }

        $this->fantasy_model->promeniCenu($_POST["submit"], $cena);
        $this->marketAdmin();
    }

    public function pretragaAdminMarket() {
        $data = $this->fantasy_model->pretragaAdmin($_POST["search"]);
        $output = "";

        if ($data->num_rows() > 0) {
            $output .= "<form action=\"promeniCenu\" method=\"post\" name=\"forma\"><table class=\"table\" >
                        <thead>
                            <tr>
                                <th>Ime i Prezime</th>
                                <th>Starost</th>
                                <th>Pozicija</th>
                                <th>Klub</th>
                                <th>Nacionalnost</th>
                                <th>Cena</th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead><tbody>";
        } else {
            $output .= "Nema podataka!";
            echo $output;
            return;
        }

        foreach ($data->result_array() as $row) {
            $idValue = $row["Id"];
            $ime = $row["Ime"];
            $prezime = $row["Prezime"];
            $pozicija = $row["Pozicija"];
            $nacionalnost = $row["Nacionalnost"];
            $cena = $row["Cena"];
            $klub = $row["Klub"];


            $output .= "<tr>
                                <th scope=\"row\"><a href=\"../NalogController/profilIgraca?id=$idValue\">" . $ime . " " . $prezime . "</a></th>
                                <td>23</td>
                                <td>" . $pozicija . "</td>
                                <td>" . $klub . "</td>
                                <td>" . $nacionalnost . "</td>
                                <td>" . $cena . "</td>
                                <td>
                                    <div style=\"width: 100px\" >
                                        
                                        <input class=\"form-control\" id=\"ex1\" type=\"text\" placeholder=\"Unesi cenu\" name=\"Cena$idValue\">
                                    </div>
                                </td>
                                <td><button type=\"button\" class=\"btn btn-default\" name=\"submit\" value=\"$idValue\" onclick=\"provera(this)\">Promeni cenu  </button></td><td><b id=\"$idValue\"></b></td>"
                    . "</tr>";
        }

        $output .= "</tbody></table></form>";
        echo $output;
    }

    public function pretragaMarketKorisnik() {
        $data = $this->fantasy_model->pretragaKorisnik($_POST["search"]);
        $output = "";

        if ($data->num_rows() > 0) {
            $output .= "<form action=\"kupiIgraca\" method=\"post\"><table class=\"table\">
                        <thead>
                            <tr>
                                <th>Ime i Prezime</th>
                                <th>Starost</th>
                                <th>Pozicija</th>
                                <th>Klub</th>
                                <th>Nacionalnost</th>
                                <th>Cena</th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead><tbody>";
        } else {
            $output .= "Nema podataka!";
            echo $output;
            return;
        }

        foreach ($data->result_array() as $row) {
            $idValue = $row["Id"];
            $ime = $row["Ime"];
            $prezime = $row["Prezime"];
            $pozicija = $row["Pozicija"];
            $nacionalnost = $row["Nacionalnost"];
            $cena = $row["Cena"];
            $klub = $row["Klub"];
            $imeDugmeta = "" . $idValue . "," . $cena;

            $output .= "<tr>
                                <th scope=\"row\"><a href=\"../NalogController/profilIgracaMarket?id=$idValue\">" . $ime . " " . $prezime . "</a></th>
                                <td>23</td>
                                <td>" . $pozicija . "</td>
                                <td>" . $klub . "</td>
                                <td>" . $nacionalnost . "</td>
                                <td>" . $cena . "</td>
                                <td><button type=\"submit\" class=\"btn btn-default\" name=\"btnKupi\" value=\"$imeDugmeta\">Kupi  </button></td>"
                    . "</tr>";
        }
        
        $output .= "</tbody></table></form>";
        echo $output;
    }
    
    public function zamenaIgraca() {
        $idRezerva = $_POST["idRezerve"];
        $idIgraca = $_POST["submit2"];
        
        $this->fantasy_model->zameni($idRezerva, $idIgraca);
        
        $this->mojTim();
    }
    
    public function pretragaIgraciGost() {
        $data = $this->fantasy_model->pretragaAdmin($_POST["search"]);
        $output = "";

        if ($data->num_rows() > 0) {
            $output .= "<table class=\"table\">
                        <thead>
                            <tr>
                                <th>Ime i Prezime</th>
                                <th>Starost</th>
                                <th>Pozicija</th>
                                <th>Klub</th>
                                <th>Nacionalnost</th>
                                <th>Cena</th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead><tbody>";
        } else {
            $output .= "Nema podataka!";
            echo $output;
            return;
        }

        foreach ($data->result_array() as $row) {
            $idValue = $row["Id"];
            $ime = $row["Ime"];
            $prezime = $row["Prezime"];
            $pozicija = $row["Pozicija"];
            $nacionalnost = $row["Nacionalnost"];
            $cena = $row["Cena"];
            $klub = $row["Klub"];


            $output .= "<tr>
                                <th scope=\"row\"><a href=\"../NalogController/profilIgracaGost?id=$idValue\">" . $ime . " " . $prezime . "</a></th>
                                <td>23</td>
                                <td>" . $pozicija . "</td>
                                <td>" . $klub . "</td>
                                <td>" . $nacionalnost . "</td>
                                <td>" . $cena . "</td>
                                <td>
                                    <div style=\"width: 100px\" >
                                        
                                        <input class=\"form-control\" id=\"ex1\" type=\"text\" placeholder=\"Unesi cenu\" name=\"Cena$idValue\">
                                    </div>
                                </td>
                                "
                    . "</tr>";
        }

        $output .= "</tbody></table>";
        echo $output;
    }
    
    public function pretragaIgraciKorisnik() {
        $data = $this->fantasy_model->pretragaAdmin($_POST["search"]);
        $output = "";

        if ($data->num_rows() > 0) {
            $output .= "<table class=\"table\">
                        <thead>
                            <tr>
                                <th>Ime i Prezime</th>
                                <th>Starost</th>
                                <th>Pozicija</th>
                                <th>Klub</th>
                                <th>Nacionalnost</th>
                                <th>Cena</th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead><tbody>";
        } else {
            $output .= "Nema podataka!";
            echo $output;
            return;
        }

        foreach ($data->result_array() as $row) {
            $idValue = $row["Id"];
            $ime = $row["Ime"];
            $prezime = $row["Prezime"];
            $pozicija = $row["Pozicija"];
            $nacionalnost = $row["Nacionalnost"];
            $cena = $row["Cena"];
            $klub = $row["Klub"];


            $output .= "<tr>
                                <th scope=\"row\"><a href=\"../NalogController/profilIgracaKorisnik?id=$idValue\">" . $ime . " " . $prezime . "</a></th>
                                <td>23</td>
                                <td>" . $pozicija . "</td>
                                <td>" . $klub . "</td>
                                <td>" . $nacionalnost . "</td>
                                <td>" . $cena . "</td>
                                
                                "
                    . "</tr>";
        }

        $output .= "</tbody></table>";
        echo $output;
    }
    
    public function igraci() {
        $this->load->view("gost_igraci.php");
    }
    
    public function igraciKorisnik() {
        $this->load->view("korisnik_igraci.php");
    }
}
