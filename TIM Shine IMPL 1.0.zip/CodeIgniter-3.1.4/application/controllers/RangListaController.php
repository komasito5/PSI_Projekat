<?php

class RangListaController extends CI_Controller {

    public function rangLista_admin() {

        $query = $this->fantasy_model->dohvatiSveTimove();

        $i = 1;
        foreach ($query->result_array() as $row) {
            $data["Row" . "$i" . "Id"] = $row["Id"];
            $data["Row" . "$i" . "Naziv"] = $row["Naziv"];
            $data["Row" . "$i" . "Rezultat"] = $row["Rezultat"];
            $data["Row" . "$i" . "KorisnickoIme"] = $row["KorisnickoIme"];
            $i++;
         }

        $data["BrojRedova"] = $i - 1;

        $this->load->view("admin_rang_lista.php", $data);
    }
    
    public function obrisiKorisnika() {
        $IdKorisnik = $_POST["submit"];
        $this->fantasy_model->obrisiKorisnika($IdKorisnik);
        $this->rangLista_admin();
    }
    
    public function rangLista_korisnik() {

        $query = $this->fantasy_model->dohvatiSveTimove();

        $i = 1;
        foreach ($query->result_array() as $row) {
            $data["Row" . "$i" . "Id"] = $row["Id"];
            $data["Row" . "$i" . "Naziv"] = $row["Naziv"];
            $data["Row" . "$i" . "Rezultat"] = $row["Rezultat"];
            $data["Row" . "$i" . "KorisnickoIme"] = $row["KorisnickoIme"];
            $i++;
         }

        $data["BrojRedova"] = $i - 1;

        $this->load->view("korisnik_rang_lista.php", $data);
    }
    
    public function rangLista_gost() {
        $query = $this->fantasy_model->dohvatiSveTimove();

        $i = 1;
        foreach ($query->result_array() as $row) {
            $data["Row" . "$i" . "Id"] = $row["Id"];
            $data["Row" . "$i" . "Naziv"] = $row["Naziv"];
            $data["Row" . "$i" . "Rezultat"] = $row["Rezultat"];
            $data["Row" . "$i" . "KorisnickoIme"] = $row["KorisnickoIme"];
            $i++;
         }

        $data["BrojRedova"] = $i - 1;

        $this->load->view("gost_rang_lista.php", $data);
    }
    
    public function pretragaRangListaAdmin() {
        $data = $this->fantasy_model->pretragaRangListaAdmin($_POST["search"]);
        $output = "";
        
        if ($data->num_rows() > 0) {
            $output .= "
                            <form action=\"obrisiKorisnika\" method=\"post\"><table class=\"table\">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Tim</th>
                            <th>Korisničko ime</th>
                            <th>Zemlja</th>
                            <th>Rezultat</th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>";
        } else {
            $output .= "Nema podataka!";
            echo $output;
            return;
        }
        
        $index = 1;
        foreach ($data->result_array() as $row) {
            $tim = $row["Klub"];
            $korisnickoIme = $row["KorisnickoIme"];
            $rezultat = $row["Rezultat"];
            $id = $row["IdKorisnik"];
            $imeDugmeta = "" . $id;
            

            $output .= "<tr>
                            <th scope=\"row\">$index</th>
                            <td>" . $tim . "</td>
                            <td><a  href=\"../NalogController/admin_profilKorisnika?id=$id\">" . $korisnickoIme . "</a></td>
                            <td>Srbija</td>
                            <td>" . $rezultat . "</td>
                            <td><button type=\"submit\" class=\"btn btn-default\" name=\"submit\" value=\"$imeDugmeta\">Obrisi korisnika</button></td>
                        </tr>";
            
            $index++;
        }
        
        $output .= "</tbody></table></form>";
        echo $output;
    }
    
    public function pretragaRangListaKorisnik() {
        $data = $this->fantasy_model->pretragaRangListaAdmin($_POST["search"]);
        $output = "";
        
        if ($data->num_rows() > 0) {
            $output .= "<table class=\"table\">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Tim</th>
                            <th>Korisničko ime</th>
                            <th>Zemlja</th>
                            <th>Rezultat</th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>";
        } else {
            $output .= "Nema podataka!";
            echo $output;
            return;
        }
        
        $index = 1;
        foreach ($data->result_array() as $row) {
            $tim = $row["Klub"];
            $korisnickoIme = $row["KorisnickoIme"];
            $rezultat = $row["Rezultat"];
            $id = $row["IdKorisnik"];
            $imeDugmeta = "" . $id;
            

            $output .= "<tr>
                            <th scope=\"row\">$index</th>
                            <td>" . $tim . "</td>
                            <td><a  href=\"../NalogController/korisnik_profilKorisnika?id=$id\">" . $korisnickoIme . "</a></td>
                            <td>Srbija</td>
                            <td>" . $rezultat . "</td>
                            
                        </tr>";
            
            $index++;
        }
        
        $output .= "</tbody></table></form>";
        echo $output;
    }
    
    public function pretragaRangListaGost() {
        $data = $this->fantasy_model->pretragaRangListaAdmin($_POST["search"]);
        $output = "";
        
        if ($data->num_rows() > 0) {
            $output .= "<table class=\"table\">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Tim</th>
                            <th>Korisničko ime</th>
                            <th>Zemlja</th>
                            <th>Rezultat</th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>";
        } else {
            $output .= "Nema podataka!";
            echo $output;
            return;
        }
        
        $index = 1;
        foreach ($data->result_array() as $row) {
            $tim = $row["Klub"];
            $korisnickoIme = $row["KorisnickoIme"];
            $rezultat = $row["Rezultat"];
            $id = $row["IdKorisnik"];
            $imeDugmeta = "" . $id;
            

            $output .= "<tr>
                            <th scope=\"row\">$index</th>
                            <td>" . $tim . "</td>
                            <td><a  href=\"../NalogController/gost_profilKorisnika?id=$id\">" . $korisnickoIme . "</a></td>
                            <td>Srbija</td>
                            <td>" . $rezultat . "</td>
                            
                        </tr>";
            
            $index++;
        }
        
        $output .= "</tbody></table></form>";
        echo $output;
    }

}
